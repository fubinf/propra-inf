;;; This is a conffile: you can edit it if you like; however,
;;; please note that if you do not want AUCTeX to override the standard
;;; Emacs TeX mode, you may unload AUCTeX completely by evaluating the
;;; form "(unload-feature 'tex-site)" (i.e., put that string into your
;;; "~/.emacs" to disable AUCTeX completely).

(if (member debian-emacs-flavor '(emacs))
    (if (file-exists-p "/usr/share/auctex/tex.el")
	(progn
	  (let ((dir (concat "/etc/"
			     (symbol-name debian-emacs-flavor)
			     "/site-lisp/auctex")))
	    (when (file-directory-p dir)
	      (debian-pkg-add-load-path-item dir)))
	  (add-to-list 'load-path "/usr/share/auctex" 'append)
	  (load "auctex.el")
	  (load "preview-latex.el"))
      (message "auctex: Package removed but not purged; skipping setup")))
